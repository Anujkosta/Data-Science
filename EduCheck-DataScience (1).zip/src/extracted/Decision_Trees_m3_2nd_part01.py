I’ll give you Python code that: 
3.  Implements a Decision Tree Classifier using sklearn (which by default uses 
Gini, but we’ll force criterion="entropy" to mimic ID3).
